document.getElementById("randomNumber1").onclick = function () {
let randomNum = Math.floor(Math.random()*71+19)
    console.log(randomNum);    
}

document.getElementById("randomNumber2").onclick = function (){
    let randomNum2 = Math.floor(Math.random()*80+70)
    console.log(randomNum2); 
}

document.getElementById("randomNumber3").onclick = function (){
console.log("Bu butona kliklediniz");
}